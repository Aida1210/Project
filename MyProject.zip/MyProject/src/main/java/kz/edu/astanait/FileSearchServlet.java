package kz.edu.astanait;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@WebServlet(urlPatterns = "/FileSearchServlet",name = "FileSearchServlet")
public class FileSearchServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getParameter("searchQuery") == null) {
            request.getRequestDispatcher("list.jsp").forward(request, response);
        }

        String searchQuery = request.getParameter("searchQuery");

        ArrayList<FileItem> matchingFiles = findMatches(searchQuery);

        request.setAttribute("matchingFiles", matchingFiles);

        request.getRequestDispatcher("search_results.jsp").forward(request, response);
    }

    private ArrayList<FileItem> findMatches(String searchQuery) {
        // We use our search query as a Regular Expression
        Pattern pattern = Pattern.compile(searchQuery, Pattern.CASE_INSENSITIVE);
        ArrayList<FileItem> fileItemArrayList = new ArrayList<>();

        FileItemList fileItemList = new FileItemList();

        for (FileItem item : fileItemList.getFilesArrayList()) {
            Matcher matcher = pattern.matcher(item.getFileName());
            boolean matchesPattern = matcher.find();
            if (matchesPattern) {
                fileItemArrayList.add(item);
            }
        }

        return fileItemArrayList;
    }
}

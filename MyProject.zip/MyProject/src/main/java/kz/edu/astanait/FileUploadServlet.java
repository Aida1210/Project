package kz.edu.astanait;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(urlPatterns = "/FileUploadServlet" ,name = "FileUploadServlet")
public class FileUploadServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter writer = response.getWriter();
        String path = "C:\\uploads\\";

        try {
            ServletFileUpload sf = new ServletFileUpload(new DiskFileItemFactory());
            List<FileItem> multifiles = sf.parseRequest(request);
            for (FileItem fi : multifiles) {
                System.out.println(fi.getName());
                String fileName = fi.getName();
                if (fileName != null) {
                    File fullFile = new File(fi.getName());
                    fi.write(new File(path + fullFile.getName()));
                    System.out.println("fff");
                }
            }
            response.sendRedirect(request.getContextPath() + "/FilesListServlet");
        } catch (FileUploadException e) {
            System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
//        // DiskFileItemFactory creates FileItem instances which keep their content either in memory,
//        // for smaller items, or in a temporary file on disk, for larger items.
//        FileItemFactory factory = new DiskFileItemFactory();
//        // This class handles multiple files per single HTML widget, sent using multipart/mixed encoding type
//        ServletFileUpload upload = new ServletFileUpload(factory);
//        try {
//            List<FileItem> items = upload.parseRequest(request);
//            for (FileItem item : items) {
//                // Adding the uploaded file to the needed directory
//                item.write(new File("C:\\uploads\\"
//                        + item.getName()));
//            }
//            // Redirects to other page after successfully uploading file
//            response.sendRedirect(request.getContextPath() + "/FilesListServlet");
//        } catch (Exception e) {
//            writer.append("<html><h1>")
//                    .append("File already exists!")
//                    .append("<h1></html>");
//        }
    }


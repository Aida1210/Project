package kz.edu.astanait;

public class FileItem {
    private String fileName;
    private double fileSize;
    private String filePath;

    public FileItem(String fileName, double fileSize, String filePath) {
        this.setFileName(fileName);
        this.setFileSize(fileSize);
        this.setFilePath(filePath);
    }

    public String getFilePath() {
        return this.filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public double getFileSize() {
        return this.fileSize;
    }

    public void setFileSize(double fileSize) {
        this.fileSize = fileSize / 1024.0D / 1024.0D;
    }
}


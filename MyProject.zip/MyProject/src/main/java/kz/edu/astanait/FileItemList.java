package kz.edu.astanait;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//



import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;

public class FileItemList {
    private double size;
    private ArrayList<FileItem> filesArrayList = new ArrayList();
    private final File fileDirectory = new File("C:\\uploads\\");

    public FileItemList() {
        this.setFilesArrayList(this.filesArrayList);
        this.setSize();
    }

    public void checkIfDirectoryExists(File directory) {
        if (!directory.exists()) {
            try {
                throw new FileNotFoundException("Such directory does not exist!");
            } catch (FileNotFoundException var3) {
                var3.printStackTrace();
            }

        }

    }

    public ArrayList<FileItem> getFilesArrayList() {
        return this.filesArrayList;
    }

    public void setFilesArrayList(ArrayList<FileItem> filesArrayList) {
        this.checkIfDirectoryExists(this.fileDirectory);
        File[] var2 = (File[])Objects.requireNonNull(this.fileDirectory.listFiles());
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            File file = var2[var4];
            FileItem fileItem = new FileItem(file.getName(), (double)file.length(), file.getPath());
            filesArrayList.add(fileItem);
        }

        this.filesArrayList = filesArrayList;
    }

    public double getSize() {
        return this.size;
    }

    public void setSize() {
        FileItem fileItem;
        for(Iterator var1 = this.filesArrayList.iterator(); var1.hasNext(); this.size += 1.0D * fileItem.getFileSize()) {
            fileItem = (FileItem)var1.next();
        }

    }
}

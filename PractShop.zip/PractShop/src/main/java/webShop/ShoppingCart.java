package webShop;

import java.util.HashSet;


/**
 * Represents cart. A vector of items (ordered pair 
�* (product, quantity)).
 */
public class ShoppingCart {
	
	private HashSet<ShoppingCartItem> items;

	public ShoppingCart() {
		items = new HashSet<ShoppingCartItem>();
	}

	public void addItem(Product product, int count) {
		items.add(new ShoppingCartItem(product, count));
	}

	public HashSet<ShoppingCartItem> getItems() {
		return items;
	}
}

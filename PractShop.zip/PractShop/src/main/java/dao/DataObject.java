package dao;

public abstract class DataObject {
	public abstract Integer getId();
	public abstract void setId(Integer id);
}
